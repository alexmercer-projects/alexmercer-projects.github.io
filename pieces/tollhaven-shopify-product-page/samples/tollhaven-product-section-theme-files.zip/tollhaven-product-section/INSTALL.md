# Tollhaven product section: install notes

Concept demo by Alex Mercer. Made for a made-up shop; check it on your own theme before publishing.

## Files

| File | Goes in |
|---|---|
| `th-main-product.liquid` | `sections/` |
| `th-variant-picker.liquid`, `th-size-guide.liquid` | `snippets/` |
| `th-product-core.js`, `th-product.js`, `th-product.css` | `assets/` |
| `product.tollhaven.json` | `templates/` |
| `size-chart.example.json` | not uploaded; paste it into the metafield |

## Steps

1. Online Store > Themes > the live theme's menu > Duplicate. Work on the copy.
2. Edit code > add each file in the folder shown above (or `shopify theme push` with Shopify CLI).
3. Settings > Custom data > Products > Add definition: name "Size chart", namespace and key `custom.size_chart`, type JSON. On the product, paste `size-chart.example.json` and change the numbers.
4. Set the swatch colors at the top of `th-product.css` (`--th-color-<color handle>`).
5. Give each product image alt text that starts with its color and " · ", for example `Olive · Back view`. The gallery shows the picked color's images.
6. On the product, choose the theme template "tollhaven". Customize > Products > tollhaven to change wording and rules.
7. Check it on a phone and a desktop, then publish the copy.

## Cart

Add to cart posts to `/cart/add.js`. Before that it fires `th:cart:add` (cancel it to handle the add yourself); after, it fires `th:cart:added`. If nothing cancels `th:cart:added`, the shopper is sent to `/cart`. Hook your theme's cart drawer to `th:cart:added` to open it instead.

## Back in stock

The form uses the store's contact form, tagged `back-in-stock`, with the variant and SKU in the message. It lands in the store's contact inbox. To automate restock emails, replace it with an app.

## Limits

- Up to three options per product.
- "Only N left" needs inventory tracking on.
- Size chart values are stored in inches.
