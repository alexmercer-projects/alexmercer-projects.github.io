/**
 * Code.gs: the parts that touch Google. Reads the sheet, writes rows, sends email,
 * and sets up the triggers. The decisions themselves are in Rules.gs.
 *
 * Install: see README.md. In short, paste these files into the sheet's
 * Extensions > Apps Script, fill in the Settings and Routing tabs, run setup()
 * once and accept the permissions.
 */

var SHEETS = { REQUESTS: 'Requests', ROUTING: 'Routing', SETTINGS: 'Settings', LOG: 'Log' };

/** Sheet header → field name. Columns are found by header, so they can be moved around. */
var COLUMNS = [
  ['Ref', 'ref'], ['Received', 'received'], ['Source', 'source'], ['Status', 'status'], ['Priority', 'priority'],
  ['Name', 'name'], ['Email', 'email'], ['Phone', 'phone'], ['Move date', 'moveDate'], ['From', 'fromTown'],
  ['To', 'toTown'], ['Home size', 'homeSize'], ['Notes', 'notes'], ['Area', 'area'], ['Estimator', 'estimator'],
  ['Estimator email', 'estimatorEmail'], ['Reply by', 'dueBy'], ['Reminded at', 'remindedAt'], ['Tags', 'tags'],
  ['Flags', 'flags'], ['Repeats', 'repeats'], ['Updated', 'updated']
];

/** Google Form question title → field name. Change the left side to match your form. */
var FORM_FIELDS = {
  'Your name': 'name',
  'Email': 'email',
  'Phone': 'phone',
  'Move date': 'moveDate',
  'Moving from': 'fromTown',
  'Moving to': 'toTown',
  'Home size': 'homeSize',
  'Anything we should know?': 'notes'
};

/** Trigger: a Google Form linked to this spreadsheet was submitted. */
function onQuoteFormSubmit(e) {
  var raw = { source: 'Google Form' };
  var values = (e && e.namedValues) || {};
  Object.keys(FORM_FIELDS).forEach(function (question) {
    if (values[question]) raw[FORM_FIELDS[question]] = values[question][0];
  });
  handleRequest_(raw);
}

/**
 * Web app endpoint for a form on your own website (Deploy > New deployment > Web app,
 * execute as you, access: anyone). The form posts its fields by name, including the
 * hidden "website" field, which people never see and bots tend to fill in.
 */
function doPost(e) {
  var p = (e && e.parameter) || {};
  var result = handleRequest_({
    source: 'Website', name: p.name, email: p.email, phone: p.phone, moveDate: p.moveDate,
    fromTown: p.fromTown, toTown: p.toTown, homeSize: p.homeSize, notes: p.notes, website: p.website
  });
  var body = { ok: !!result, ref: result && result.outcome !== 'spam' ? result.row.ref : null };
  return ContentService.createTextOutput(JSON.stringify(body)).setMimeType(ContentService.MimeType.JSON);
}

/** One request, start to finish, under a lock so two at once can't get the same row or number. */
function handleRequest_(raw) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
  } catch (err) {
    logEvent_('Error', '', 'Could not get the lock in 30 s; request saved to the Log tab only: ' + JSON.stringify(raw));
    return null;
  }
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var cfg = readConfig_(ss);
    var table = readRequests_(ss);
    var props = PropertiesService.getScriptProperties();
    var seq = (parseInt(props.getProperty('nextSeq'), 10) || 1);
    var result = processRequest(raw, { now: new Date(), rows: table.rows, seq: seq, cfg: cfg });

    if (result.outcome === 'merged') {
      writeRow_(table, result.index, result.row);
    } else {
      writeRow_(table, -1, result.row);
      props.setProperty('nextSeq', String(seq + 1));
    }
    SpreadsheetApp.flush();
    result.emails.forEach(function (mail) { sendFor_(mail, result.row, cfg, ss.getUrl()); });
    logEvent_(result.outcome, result.row.ref, result.log.map(function (l) { return l.step + ': ' + l.detail; }).join(' | '));
    return result;
  } catch (err) {
    logEvent_('Error', '', String(err && err.stack || err) + ' | request: ' + JSON.stringify(raw));
    notifyOwner_('Quote form error', 'A quote request hit an error and was saved to the Log tab.\n\n' + err);
    return null;
  } finally {
    lock.releaseLock();
  }
}

/** Send one email, checking the daily quota first. Failures go to the Log tab and never stop the row. */
function sendFor_(mail, row, cfg, sheetUrl) {
  var message;
  if (mail.kind === 'confirmation') message = confirmationEmail(row, cfg);
  else if (mail.kind === 'alert') message = alertEmail(row, cfg, sheetUrl);
  else if (mail.kind === 'repeat') message = repeatEmail(row, cfg);
  else if (mail.kind === 'reminder') message = reminderEmail(row, cfg);
  else return;
  if (!mail.to) { logEvent_('Email skipped', row.ref, mail.kind + ': no address on the Routing or Settings tab'); return; }
  if (MailApp.getRemainingDailyQuota() < 1) {
    logEvent_('Email skipped', row.ref, mail.kind + ' to ' + mail.to + ': daily email quota used up');
    return;
  }
  try {
    var options = { to: mail.to, subject: message.subject, body: message.text, htmlBody: message.html, name: cfg.businessName };
    if (mail.kind === 'confirmation' && cfg.replyTo) options.replyTo = cfg.replyTo;
    if (mail.kind !== 'confirmation' && row.email) options.replyTo = row.email;
    MailApp.sendEmail(options);
  } catch (err) {
    logEvent_('Email failed', row.ref, mail.kind + ' to ' + mail.to + ': ' + err);
  }
}

/** Trigger, every hour: remind estimators about requests still New past their reply time. */
function remindOverdue() {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) return; // a request is being handled; the next run will catch up
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var cfg = readConfig_(ss);
    var table = readRequests_(ss);
    var now = new Date();
    findOverdue(table.rows, now).forEach(function (row) {
      var index = table.rows.indexOf(row);
      sendFor_({ to: row.estimatorEmail || cfg.owner.email, kind: 'reminder' }, row, cfg);
      if (cfg.owner.email && cfg.owner.email !== row.estimatorEmail) sendFor_({ to: cfg.owner.email, kind: 'reminder' }, row, cfg);
      row.remindedAt = now;
      row.updated = now;
      writeRow_(table, index, row);
      logEvent_('Reminder', row.ref, 'Still New past ' + row.dueBy);
    });
  } finally {
    lock.releaseLock();
  }
}

/** Trigger, every morning: the summary email to the office. */
function sendMorningDigest() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var cfg = readConfig_(ss);
  var table = readRequests_(ss);
  var message = digestEmail(buildDigest(table.rows, new Date(), cfg), cfg);
  if (!cfg.owner.email) { logEvent_('Digest skipped', '', 'No Office email on the Settings tab'); return; }
  MailApp.sendEmail({ to: cfg.owner.email, subject: message.subject, body: message.text, htmlBody: message.html, name: cfg.businessName });
  logEvent_('Digest', '', message.subject);
}

/** Run once by hand. Creates missing tabs and headers, then (re)creates the three triggers. */
function setup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var requests = ss.getSheetByName(SHEETS.REQUESTS) || ss.insertSheet(SHEETS.REQUESTS);
  if (requests.getLastRow() === 0) {
    requests.appendRow(COLUMNS.map(function (c) { return c[0]; }));
    requests.setFrozenRows(1);
  }
  var statusCol = headerIndex_(requests, 'Status');
  if (statusCol > 0) {
    var rule = SpreadsheetApp.newDataValidation()
      .requireValueInList([STATUS.NEW, STATUS.CONTACTED, STATUS.QUOTED, STATUS.BOOKED, STATUS.LOST, STATUS.CHECK, STATUS.SPAM], true)
      .build();
    requests.getRange(2, statusCol, requests.getMaxRows() - 1, 1).setDataValidation(rule);
  }
  if (!ss.getSheetByName(SHEETS.LOG)) ss.insertSheet(SHEETS.LOG).appendRow(['When', 'What', 'Ref', 'Details']);

  var handlers = ['onQuoteFormSubmit', 'remindOverdue', 'sendMorningDigest'];
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (handlers.indexOf(t.getHandlerFunction()) !== -1) ScriptApp.deleteTrigger(t);
  });
  var cfg = readConfig_(ss);
  ScriptApp.newTrigger('onQuoteFormSubmit').forSpreadsheet(ss).onFormSubmit().create();
  ScriptApp.newTrigger('remindOverdue').timeBased().everyHours(1).create();
  ScriptApp.newTrigger('sendMorningDigest').timeBased().atHour(cfg.digestHour).everyDays(1).create();

  var props = PropertiesService.getScriptProperties();
  if (!props.getProperty('nextSeq')) props.setProperty('nextSeq', String(Math.max(1, requests.getLastRow())));
  logEvent_('Setup', '', 'Tabs checked, 3 triggers created');
}

/* ---------- sheet helpers ---------- */

function readConfig_(ss) {
  var settings = {};
  var s = ss.getSheetByName(SHEETS.SETTINGS);
  if (s && s.getLastRow() > 1) {
    s.getRange(2, 1, s.getLastRow() - 1, 2).getValues().forEach(function (r) { if (r[0]) settings[String(r[0]).trim()] = r[1]; });
  }
  var routing = [];
  var r = ss.getSheetByName(SHEETS.ROUTING);
  if (r && r.getLastRow() > 1) {
    r.getRange(2, 1, r.getLastRow() - 1, 4).getValues().forEach(function (v) {
      routing.push({ town: v[0], area: v[1], estimator: v[2], email: v[3] });
    });
  }
  return buildConfig(settings, routing);
}

function readRequests_(ss) {
  var sheet = ss.getSheetByName(SHEETS.REQUESTS);
  var values = sheet.getDataRange().getValues();
  var headers = values.shift() || [];
  var map = {};
  COLUMNS.forEach(function (c) { map[c[1]] = headers.indexOf(c[0]); });
  var rows = values.map(function (v) {
    var row = {};
    COLUMNS.forEach(function (c) { row[c[1]] = map[c[1]] >= 0 ? v[map[c[1]]] : ''; });
    return row;
  });
  return { sheet: sheet, headers: headers, map: map, rows: rows };
}

/** index -1 appends; otherwise rewrites that data row (0-based, below the header). */
function writeRow_(table, index, row) {
  var width = table.headers.length;
  var out = [];
  for (var i = 0; i < width; i++) out.push('');
  if (index >= 0) {
    out = table.sheet.getRange(index + 2, 1, 1, width).getValues()[0];
  }
  COLUMNS.forEach(function (c) {
    var col = table.map[c[1]];
    if (col >= 0 && row[c[1]] !== undefined) out[col] = row[c[1]] === null ? '' : row[c[1]];
  });
  if (index >= 0) table.sheet.getRange(index + 2, 1, 1, width).setValues([out]);
  else { table.sheet.appendRow(out); table.rows.push(row); }
}

function headerIndex_(sheet, header) {
  if (sheet.getLastColumn() === 0) return -1;
  return sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].indexOf(header) + 1;
}

function logEvent_(what, ref, details) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var log = ss.getSheetByName(SHEETS.LOG) || ss.insertSheet(SHEETS.LOG);
  log.appendRow([new Date(), what, ref, String(details).slice(0, 45000)]);
}

function notifyOwner_(subject, body) {
  try {
    var cfg = readConfig_(SpreadsheetApp.getActiveSpreadsheet());
    if (cfg.owner.email && MailApp.getRemainingDailyQuota() > 0) MailApp.sendEmail(cfg.owner.email, subject, body);
  } catch (err) { /* already in the Log tab */ }
}
