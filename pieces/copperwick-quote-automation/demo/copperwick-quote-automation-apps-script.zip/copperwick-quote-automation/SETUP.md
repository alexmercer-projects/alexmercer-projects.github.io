# Copperwick quote automation: setup

Concept demo by Alex Mercer. Copperwick Moving Co. and every name, town and address in these files are made up. Swap in your own on the Routing and Settings tabs.

## What you need

- A Google account (free gmail.com or Google Workspace)
- A Google Sheet, and a Google Form or a form on your website

## Install (about 20 minutes)

1. **The sheet.** Import `Copperwick-quote-requests-DEMO.xlsx` into Google Sheets (File > Import), or use your own sheet. `setup()` adds the Requests and Log tabs if they're missing, but you need Routing and Settings.
2. **The form.** In Google Forms, open Responses > Link to Sheets and pick this spreadsheet. If your question titles differ from the ones in `FORM_FIELDS` at the top of `Code.gs`, change the left-hand side of that list to match.
3. **The script.** In the sheet, Extensions > Apps Script. Replace the starter file with `Code.gs`, then add `Rules.gs` and `Emails.gs` (the + next to Files > Script). In Project Settings, tick "Show appsscript.json" and paste in the one from this folder, or just set the time zone to yours.
4. **Routing tab.** One row per town: Town, Area, Estimator, Email. Anything moving to a town that isn't listed counts as long distance.
5. **Settings tab.** Office hours, open days, the reply window in business hours, the rush cutoff in days, the duplicate window, and the office, long-distance and reply-to email addresses.
6. **Run `setup()` once.** Pick it in the function menu and press Run. Google asks for permission to edit the sheet and send email as you. It creates the Status dropdown and three triggers:
   - `onQuoteFormSubmit`, on every form submission
   - `remindOverdue`, every hour
   - `sendMorningDigest`, every day at the "Morning digest hour"
7. **Test it.** Submit the form with your own email and check the Requests tab, the Log tab and your inbox.

## Optional: a form on your own website

Deploy > New deployment > Web app, execute as you, access "Anyone". Point your site's form at the web app URL with `method="post"` and these field names: `name`, `email`, `phone`, `moveDate`, `fromTown`, `toTown`, `homeSize`, `notes`, plus a hidden `website` field (leave it empty and hidden; bots fill it in). The script answers with JSON: `{"ok": true, "ref": "CWM-2611-0012"}`.

## Limits worth knowing

- Apps Script can email 100 recipients a day from a free Google account and 1,500 from Workspace. The script checks before each send; if the quota is used up, the row is still saved and the skip is written to the Log tab.
- Triggers on a free account get 90 minutes of run time a day in total. Each request takes about a second.
- Google may change these limits. Current numbers: https://developers.google.com/apps-script/guides/services/quotas

## Changing the rules

All decisions are in `Rules.gs`: spam, contact checks, repeats, routing, priority and the reply-by time. Email wording is in `Emails.gs`. Neither file uses any Google service, so you can test changes with `node --test tests/` from the repo.
